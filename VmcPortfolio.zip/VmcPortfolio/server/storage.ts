import { 
  users, type User, type InsertUser,
  contactSubmissions, type ContactSubmission, type InsertContactSubmission,
  portfolioItems, type PortfolioItem, type InsertPortfolioItem,
  services, type Service, type InsertService 
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, count } from "drizzle-orm";

// Storage interface with CRUD operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Contact form operations
  createContactSubmission(submission: InsertContactSubmission): Promise<ContactSubmission>;
  getContactSubmissions(): Promise<ContactSubmission[]>;

  // Portfolio operations
  getPortfolioItems(): Promise<PortfolioItem[]>;
  getPortfolioItemById(id: number): Promise<PortfolioItem | undefined>;
  
  // Services operations
  getServices(): Promise<Service[]>;
  getServiceById(id: number): Promise<Service | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private contactSubmissions: Map<number, ContactSubmission>;
  private portfolioItems: Map<number, PortfolioItem>;
  private services: Map<number, Service>;
  
  private userId: number;
  private contactSubmissionId: number;
  private portfolioItemId: number;
  private serviceId: number;

  constructor() {
    this.users = new Map();
    this.contactSubmissions = new Map();
    this.portfolioItems = new Map();
    this.services = new Map();
    
    this.userId = 1;
    this.contactSubmissionId = 1;
    this.portfolioItemId = 1;
    this.serviceId = 1;
    
    // Initialize with sample data
    this.initializeServices();
    this.initializePortfolioItems();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Contact form operations
  async createContactSubmission(insertSubmission: InsertContactSubmission): Promise<ContactSubmission> {
    const id = this.contactSubmissionId++;
    const now = new Date();
    const submission: ContactSubmission = { 
      ...insertSubmission, 
      id, 
      submittedAt: now,
      company: insertSubmission.company || null
    };
    this.contactSubmissions.set(id, submission);
    return submission;
  }

  async getContactSubmissions(): Promise<ContactSubmission[]> {
    return Array.from(this.contactSubmissions.values());
  }

  // Portfolio operations
  async getPortfolioItems(): Promise<PortfolioItem[]> {
    return Array.from(this.portfolioItems.values());
  }

  async getPortfolioItemById(id: number): Promise<PortfolioItem | undefined> {
    return this.portfolioItems.get(id);
  }

  // Services operations
  async getServices(): Promise<Service[]> {
    return Array.from(this.services.values());
  }

  async getServiceById(id: number): Promise<Service | undefined> {
    return this.services.get(id);
  }

  // Initialize with sample data
  private initializeServices() {
    const servicesList: InsertService[] = [
      {
        title: "CNC Milling",
        description: "High-precision CNC milling services with our advanced VMC machines. Capable of handling complex geometries and tight tolerances.",
        icon: "cut",
        features: ["3-axis and 5-axis machining", "Complex contours and surfaces", "Tight tolerance requirements"]
      },
      {
        title: "Prototyping",
        description: "Rapid prototyping services to quickly validate your designs before full production. Fast turnaround with exceptional quality.",
        icon: "drafting-compass",
        features: ["Quick iteration capabilities", "Design for manufacturability feedback", "Material selection guidance"]
      },
      {
        title: "Production Machining",
        description: "Efficient production machining services for medium to large volume manufacturing runs with consistent quality.",
        icon: "cogs",
        features: ["Medium to large production runs", "Quality control and inspection", "Just-in-time manufacturing capability"]
      },
      {
        title: "Design & Engineering",
        description: "Collaborative design and engineering support to optimize your parts for manufacturing efficiency and performance.",
        icon: "pencil-ruler",
        features: ["CAD/CAM design assistance", "Design for manufacturing (DFM)", "Technical documentation"]
      },
      {
        title: "Material Finishing",
        description: "Comprehensive finishing services to give your machined parts the perfect final appearance and performance characteristics.",
        icon: "microscope",
        features: ["Surface treatments and finishes", "Anodizing and plating", "Powder coating and painting"]
      },
      {
        title: "Special Applications",
        description: "Specialized machining services for unique applications and challenging materials, backed by our extensive experience.",
        icon: "tools",
        features: ["Exotic material machining", "Aerospace and defense components", "Medical device manufacturing"]
      }
    ];

    servicesList.forEach(service => {
      const id = this.serviceId++;
      // Ensure features is not undefined
      const processedService = {
        ...service,
        id,
        features: service.features || []
      };
      this.services.set(id, processedService);
    });
  }

  private initializePortfolioItems() {
    const portfolioList: InsertPortfolioItem[] = [
      {
        title: "Automotive Components",
        description: "Precision-machined engine parts with tight tolerances",
        imageUrl: "https://images.unsplash.com/photo-1495186578399-253dc42098ef?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
        category: "Automotive"
      },
      {
        title: "Aerospace Parts",
        description: "Lightweight aluminum components for aircraft systems",
        imageUrl: "https://images.unsplash.com/photo-1583009663341-31412631c9eb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
        category: "Aerospace"
      },
      {
        title: "Medical Devices",
        description: "High-precision surgical instrument components",
        imageUrl: "https://images.unsplash.com/photo-1581092787765-e31bd53b30c5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
        category: "Medical"
      },
      {
        title: "Industrial Equipment",
        description: "Heavy-duty components for manufacturing machinery",
        imageUrl: "https://images.unsplash.com/photo-1610262325577-9686ac09d9a1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
        category: "Industrial"
      },
      {
        title: "Prototype Development",
        description: "Rapid prototype iterations for product development",
        imageUrl: "https://images.unsplash.com/photo-1534313314376-a72289b6181e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
        category: "Prototyping"
      },
      {
        title: "Electronics Housing",
        description: "Precision-machined enclosures for sensitive electronics",
        imageUrl: "https://images.unsplash.com/photo-1631667960995-9748aca6e9ca?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
        category: "Electronics"
      }
    ];

    portfolioList.forEach(item => {
      const id = this.portfolioItemId++;
      this.portfolioItems.set(id, { ...item, id });
    });
  }
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  // Contact form operations
  async createContactSubmission(insertSubmission: InsertContactSubmission): Promise<ContactSubmission> {
    // Ensure company field is null if undefined
    const submission = {
      ...insertSubmission,
      company: insertSubmission.company || null,
      submittedAt: new Date(),
    };
    
    const [result] = await db
      .insert(contactSubmissions)
      .values(submission)
      .returning();
    
    return result;
  }
  
  async getContactSubmissions(): Promise<ContactSubmission[]> {
    return await db.select().from(contactSubmissions).orderBy(desc(contactSubmissions.submittedAt));
  }
  
  // Portfolio operations
  async getPortfolioItems(): Promise<PortfolioItem[]> {
    return await db.select().from(portfolioItems);
  }
  
  async getPortfolioItemById(id: number): Promise<PortfolioItem | undefined> {
    const [item] = await db.select().from(portfolioItems).where(eq(portfolioItems.id, id));
    return item || undefined;
  }
  
  // Services operations
  async getServices(): Promise<Service[]> {
    return await db.select().from(services);
  }
  
  async getServiceById(id: number): Promise<Service | undefined> {
    const [service] = await db.select().from(services).where(eq(services.id, id));
    return service || undefined;
  }
  
  // Seed initial data
  async seedInitialData() {
    // Check if services already exist
    const existingServices = await db.select({ count: count() }).from(services);
    if (existingServices[0].count === 0) {
      // Seed services
      const servicesList: InsertService[] = [
        {
          title: "CNC Milling on Jyoti RDX 20",
          description: "High-precision CNC milling services with our Jyoti RDX 20 VMC machine. Capable of handling complex geometries and tight tolerances with 10000 RPM and through coolant capability.",
          icon: "cut",
          features: ["3-axis machining", "Through coolant technology", "Size capacity: 800 X 500 X 500", "10000 RPM precision"]
        },
        {
          title: "Prototyping",
          description: "Rapid prototyping services to quickly validate your designs before full production. Fast turnaround with exceptional quality.",
          icon: "drafting-compass",
          features: ["Quick iteration capabilities", "Design for manufacturability feedback", "Material selection guidance"]
        },
        {
          title: "Production Machining",
          description: "Efficient production machining services for medium to large volume manufacturing runs with consistent quality.",
          icon: "cogs",
          features: ["Medium to large production runs", "Quality control and inspection", "Just-in-time manufacturing capability"]
        },
        {
          title: "Design & Engineering",
          description: "Collaborative design and engineering support to optimize your parts for manufacturing efficiency and performance.",
          icon: "pencil-ruler",
          features: ["CAD/CAM design assistance", "Design for manufacturing (DFM)", "Technical documentation"]
        },
        {
          title: "Material Finishing",
          description: "Comprehensive finishing services to give your machined parts the perfect final appearance and performance characteristics.",
          icon: "microscope",
          features: ["Surface treatments and finishes", "Anodizing and plating", "Powder coating and painting"]
        },
        {
          title: "Special Applications",
          description: "Specialized machining services for unique applications and challenging materials, backed by our extensive experience.",
          icon: "tools",
          features: ["Exotic material machining", "Aerospace and defense components", "Medical device manufacturing"]
        }
      ];
      
      await db.insert(services).values(servicesList);
    }
    
    // Check if portfolio items already exist
    const existingPortfolioItems = await db.select({ count: count() }).from(portfolioItems);
    if (existingPortfolioItems[0].count === 0) {
      // Seed portfolio items with newer VMC machining images (2018+) including our specific machine models
      const portfolioList: InsertPortfolioItem[] = [
        {
          title: "VMC 1 - RDX 20 (2018)",
          description: "Our VMC 1 machine - Jyoti RDX 20 model from 2018 with 10000 RPM, 3 Axis with Through Coolant capability, size 800 X 500 X 500",
          imageUrl: "https://images.unsplash.com/photo-1524514587686-e2909d726e9b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
          category: "Our Machines"
        },
        {
          title: "Jyoti RDX 20 Milling Operations",
          description: "Milling operations performed on our VMC 1 machine with precision 3-axis control",
          imageUrl: "https://images.unsplash.com/photo-1535813547-99c456a41d4a?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
          category: "Our Machines"
        },
        {
          title: "Precision Aerospace Components",
          description: "Custom titanium components for aerospace applications made on our Jyoti RDX 20 (2022)",
          imageUrl: "https://images.unsplash.com/photo-1562408590-e32931084e23?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
          category: "Aerospace"
        },
        {
          title: "Medical Implant Prototypes",
          description: "Titanium alloy implant components with biocompatible finishing using our Jyoti RDX 20 VMC 1 (2021)",
          imageUrl: "https://images.unsplash.com/photo-1530026186672-2cd00ffc50fe?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
          category: "Medical"
        },
        {
          title: "High-Performance Engine Parts",
          description: "Custom racing engine components machined from billet aluminum (2020)",
          imageUrl: "https://images.unsplash.com/photo-1579275542618-a1dfed5f54ba?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
          category: "Automotive"
        },
        {
          title: "Industrial Automation Components",
          description: "Precision parts for robotic assembly systems made with our Jyoti RDX 20 VMC 1 (2019)",
          imageUrl: "https://images.unsplash.com/photo-1624397640148-949ff7e300a3?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
          category: "Industrial"
        },
        {
          title: "Advanced Cooling System",
          description: "Water-cooled heat sink assembly for high-performance computing using through coolant capability (2018)",
          imageUrl: "https://images.unsplash.com/photo-1628745277895-63fd98bcb1e5?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
          category: "Electronics"
        },
        {
          title: "Custom Tooling Solutions",
          description: "Specialized fixture systems for manufacturing applications using our Jyoti RDX 20 machine (2023)",
          imageUrl: "https://images.unsplash.com/photo-1612690669207-fed642192c40?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
          category: "Special Applications"
        }
      ];
      
      await db.insert(portfolioItems).values(portfolioList);
    }
  }
}

// Use Database storage instead of memory storage
export const storage = new DatabaseStorage();
