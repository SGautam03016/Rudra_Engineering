import Hero from "@/components/sections/hero";
import About from "@/components/sections/about";
import Services from "@/components/sections/services";
import Portfolio from "@/components/sections/portfolio";
import Testimonials from "@/components/sections/testimonials";
import Cta from "@/components/sections/cta";
import Contact from "@/components/sections/contact";
import CompanyProfile from "@/components/sections/company-profile";

const Home = () => {
  return (
    <div>
      <Hero />
      <About />
      <Services />
      <Portfolio />
      <CompanyProfile />
      <Testimonials />
      <Cta />
      <Contact />
    </div>
  );
};

export default Home;
