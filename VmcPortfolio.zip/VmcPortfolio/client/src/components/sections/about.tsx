import { Card } from "@/components/ui/card";
import { 
  Cog, Award, Clock, Factory, Settings, Shield 
} from "lucide-react";
import { COMPANY_FOUNDED_YEAR } from "@/lib/constants";

const About = () => {
  const features = [
    {
      icon: <Cog className="h-6 w-6" />,
      title: "High Precision",
      description: "Tight tolerances with 3-axis capability"
    },
    {
      icon: <Award className="h-6 w-6" />,
      title: "Quality Assurance",
      description: "Stringent inspection processes"
    },
    {
      icon: <Clock className="h-6 w-6" />,
      title: "Reliability",
      description: "On-time delivery commitment"
    },
    {
      icon: <Factory className="h-6 w-6" />,
      title: "Experience",
      description: `Established in ${COMPANY_FOUNDED_YEAR}`
    },
    {
      icon: <Settings className="h-6 w-6" />,
      title: "Advanced Technology",
      description: "Jyoti RDX 20 with 10000 RPM"
    },
    {
      icon: <Shield className="h-6 w-6" />,
      title: "Customer Support",
      description: "Dedicated service team"
    }
  ];

  return (
    <section id="about" className="py-16 md:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold font-heading text-gray-900 mb-4">
            About Rudra Engineering
          </h2>
          <p className="text-xl font-medium font-heading text-gray-700 max-w-3xl mx-auto">
            Leading provider of precision engineering solutions since {COMPANY_FOUNDED_YEAR}
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="rounded-lg overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1617788138017-80ad40651399?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
              alt="Our modern VMC machining facility" 
              className="object-cover h-full w-full aspect-[16/9]"
            />
          </div>
          <div>
            <h3 className="text-2xl font-bold font-heading text-gray-900 mb-4">Our Story</h3>
            <p className="mb-4 text-gray-700">
              Rudra Engineering is a leading provider of precision engineering solutions, founded in 2018. Based in Rauki, Rajkot, the company has swiftly established itself as a trusted name in the manufacturing industry, particularly in the field of precision machining. With a relentless focus on quality and innovation, Rudra Engineering has consistently delivered high-performance products to a diverse range of industries.
            </p>
            <p className="mb-6 text-gray-700">
              The company's journey began with a commitment to excellence and a vision to provide precision-engineered solutions using the most advanced technologies. Over the years, Rudra Engineering has expanded its operations, continually investing in state-of-the-art machinery and skilled professionals to meet the growing demands of its clients.
            </p>
            
            <h3 className="text-2xl font-bold font-heading text-gray-900 mb-4 mt-8">Our Mission</h3>
            <p className="mb-6 text-gray-700">
              Our mission is to offer world-class manufacturing services through innovation, technology, and customer satisfaction. We strive to exceed expectations by delivering high-quality products with unmatched precision. We aim to provide a seamless and transparent experience for our clients, from design to production, and to foster an environment of continuous improvement within our organization.
            </p>
            
            <div className="grid grid-cols-2 gap-6 mt-8">
              {features.map((feature, index) => (
                <div key={index} className="flex items-start">
                  <div className="flex-shrink-0 h-12 w-12 flex items-center justify-center rounded-md bg-primary-100 text-primary-600">
                    {feature.icon}
                  </div>
                  <div className="ml-4">
                    <h4 className="text-lg font-medium font-heading text-gray-900">{feature.title}</h4>
                    <p className="mt-2 text-gray-700">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
