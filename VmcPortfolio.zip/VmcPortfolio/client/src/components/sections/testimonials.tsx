import { Card } from "@/components/ui/card";
import { Star, User } from "lucide-react";

const Testimonials = () => {
  const testimonials = [
    {
      id: 1,
      content: "PrecisionCraft delivered exceptional quality components for our aerospace project. Their attention to detail and ability to meet tight tolerances was impressive.",
      author: "Michael Johnson",
      position: "Engineering Manager, AeroTech Industries",
      rating: 5
    },
    {
      id: 2,
      content: "We've been working with PrecisionCraft for over 5 years on our medical device components. Their quality is consistently excellent and delivery is always on time.",
      author: "Sarah Williams",
      position: "Procurement Director, MedTech Solutions",
      rating: 5
    },
    {
      id: 3,
      content: "Their prototyping services helped us iterate quickly on our design. The engineering support they provided was invaluable to optimizing our product for manufacturing.",
      author: "David Chen",
      position: "Product Development, InnovateX",
      rating: 4.5
    }
  ];

  // Helper function to render stars
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating - fullStars >= 0.5;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`full-${i}`} className="fill-primary-500 text-primary-500 h-4 w-4" />);
    }
    
    if (hasHalfStar) {
      stars.push(
        <svg 
          key="half" 
          className="h-4 w-4 text-primary-500"
          xmlns="http://www.w3.org/2000/svg" 
          viewBox="0 0 24 24" 
          fill="none" 
          stroke="currentColor" 
          strokeWidth="2" 
          strokeLinecap="round" 
          strokeLinejoin="round"
        >
          <path d="M12 17.8 5.8 21 7 14.1 2 9.3l7-1L12 2" fill="currentColor" />
          <path d="M12 17.8 18.2 21 17 14.1l5-4.8-7-1L12 2" />
        </svg>
      );
    }
    
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="text-primary-500 h-4 w-4" />);
    }
    
    return stars;
  };

  return (
    <section className="py-16 md:py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold font-heading text-gray-900 mb-4">
            Client Testimonials
          </h2>
          <p className="text-xl font-medium font-heading text-gray-700 max-w-3xl mx-auto">
            Hear what our clients have to say about our precision machining services
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <Card key={testimonial.id} className="p-6">
              <div className="flex items-center mb-4">
                <div className="text-primary-500 flex">
                  {renderStars(testimonial.rating)}
                </div>
              </div>
              <blockquote className="text-gray-700 italic mb-6">
                "{testimonial.content}"
              </blockquote>
              <div className="flex items-center">
                <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center mr-3 text-primary-700">
                  <User className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-medium text-gray-900">{testimonial.author}</p>
                  <p className="text-sm text-gray-500">{testimonial.position}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
