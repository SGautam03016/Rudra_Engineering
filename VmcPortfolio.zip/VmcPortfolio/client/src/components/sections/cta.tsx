import { Button } from "@/components/ui/button";
import { Phone } from "lucide-react";

const Cta = () => {
  const scrollToContact = () => {
    const contactSection = document.getElementById('contact');
    if (contactSection) {
      window.scrollTo({
        top: contactSection.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section className="py-12 md:py-20 bg-primary-900 relative">
      <div className="absolute inset-0 bg-gradient-to-r from-primary-800 to-primary-900 opacity-95"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white font-heading mb-4">
            Ready to Start Your Next Project?
          </h2>
          <p className="text-xl text-primary-100 mb-8">
            Contact us today to discuss your precision machining needs and get a custom quote.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg"
              onClick={scrollToContact}
              className="bg-white text-primary-800 hover:bg-primary-50"
            >
              Request a Quote
            </Button>
            <Button 
              size="lg"
              variant="outline" 
              asChild
              className="text-white border-white hover:bg-primary-800"
            >
              <a href="tel:+1234567890" className="flex items-center gap-2">
                <Phone className="h-4 w-4" /> Call Us
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Cta;
