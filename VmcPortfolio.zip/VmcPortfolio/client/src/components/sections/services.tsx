import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Check } from "lucide-react";
import { 
  Scissors, Compass, Cog, PenTool, 
  Microscope, Wrench, Factory, Activity 
} from "lucide-react";
import { Service } from "@shared/schema";

const getIconComponent = (iconName: string) => {
  switch (iconName) {
    case "cut":
      return <Scissors className="h-6 w-6" />;
    case "drafting-compass":
      return <Compass className="h-6 w-6" />;
    case "cogs":
      return <Cog className="h-6 w-6" />;
    case "pencil-ruler":
      return <PenTool className="h-6 w-6" />;
    case "microscope":
      return <Microscope className="h-6 w-6" />;
    case "tools":
      return <Wrench className="h-6 w-6" />;
    default:
      return <Cog className="h-6 w-6" />;
  }
};

const Services = () => {
  const { data: services, isLoading, error } = useQuery({
    queryKey: ["/api/services"],
  });

  // Fallback services data if API fails
  const fallbackServices: Service[] = [
    {
      id: 1,
      title: "CNC Milling on Jyoti RDX 20",
      description: "High-precision CNC milling services with our Jyoti RDX 20 VMC machine. Capable of handling complex geometries and tight tolerances with 10000 RPM and through coolant capability.",
      icon: "cut",
      features: ["3-axis machining", "Through coolant technology", "Size capacity: 800 X 500 X 500", "10000 RPM precision"]
    },
    {
      id: 2,
      title: "Prototyping",
      description: "Rapid prototyping services to quickly validate your designs before full production. Fast turnaround with exceptional quality.",
      icon: "drafting-compass",
      features: ["Quick iteration capabilities", "Design for manufacturability feedback", "Material selection guidance"]
    },
    {
      id: 3,
      title: "Production Machining",
      description: "Efficient production machining services for medium to large volume manufacturing runs with consistent quality.",
      icon: "cogs",
      features: ["Medium to large production runs", "Quality control and inspection", "Just-in-time manufacturing capability"]
    },
    {
      id: 4,
      title: "Design & Engineering",
      description: "Collaborative design and engineering support to optimize your parts for manufacturing efficiency and performance.",
      icon: "pencil-ruler",
      features: ["CAD/CAM design assistance", "Design for manufacturing (DFM)", "Technical documentation"]
    },
    {
      id: 5,
      title: "Material Finishing",
      description: "Comprehensive finishing services to give your machined parts the perfect final appearance and performance characteristics.",
      icon: "microscope",
      features: ["Surface treatments and finishes", "Anodizing and plating", "Powder coating and painting"]
    },
    {
      id: 6,
      title: "Special Applications",
      description: "Specialized machining services for unique applications and challenging materials, backed by our extensive experience.",
      icon: "tools",
      features: ["Exotic material machining", "Aerospace and defense components", "Medical device manufacturing"]
    }
  ];

  const displayServices = services || fallbackServices;

  return (
    <section id="services" className="py-16 md:py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold font-heading text-gray-900 mb-4">
            Our Services
          </h2>
          <p className="text-xl font-medium font-heading text-gray-700 max-w-3xl mx-auto">
            Reckoned to be the prominent name in industry, we are engaged in manufacturing and exporting a quality range of machines
          </p>
        </div>
        
        <div className="mb-12 bg-white p-6 rounded-lg shadow-sm">
          <h3 className="text-2xl font-bold font-heading text-gray-900 mb-4">Our Capabilities</h3>
          <p className="mb-4 text-gray-700">
            At Rudra Engineering, we specialize in Vertical Machining Center (VMC) machining, one of the most versatile and advanced technologies used for high-precision manufacturing. Our fleet of VMC machines enables us to produce a wide variety of components and products with exceptional precision, accuracy, and efficiency.
          </p>
          <p className="mb-4 text-gray-700">
            We use quality grades of various metals as per customers requirements in the manufacturing of our range that comprise of precision components, CNC machined components, engineering components. Job Work on CNC Vertical Machining Center offered by us is precisely designed under the guidance of experts our range is free from design flaws and complies with the prescribed quality standards.
          </p>
          <p className="mb-4 text-gray-700">
            Moreover, each product is stringently tested on varied parameters before being delivered in the market. A Test report may be generated according to requirements.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {displayServices.map((service) => (
            <Card key={service.id} className="p-6 hover:shadow-md transition-shadow">
              <div className="h-14 w-14 rounded-lg bg-primary-100 flex items-center justify-center mb-5">
                {getIconComponent(service.icon)}
              </div>
              <h3 className="text-xl font-bold font-heading text-gray-900 mb-3">
                {service.title}
              </h3>
              <p className="text-gray-700 mb-4">
                {service.description}
              </p>
              <ul className="mt-4 space-y-2">
                {service.features?.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <Check className="h-4 w-4 text-primary-600 mr-2" />
                    <span className="text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>
            </Card>
          ))}
        </div>
        
        <div className="mt-16 bg-white p-6 rounded-lg shadow-sm">
          <h3 className="text-2xl font-bold font-heading text-gray-900 mb-4">Industries We Serve</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
            <div className="flex items-start">
              <div className="flex-shrink-0 h-12 w-12 flex items-center justify-center rounded-md bg-primary-100 text-primary-600 mr-4">
                <Factory className="h-6 w-6" />
              </div>
              <div>
                <h4 className="text-lg font-medium text-gray-900">Automotive Industry</h4>
                <p className="text-gray-700">
                  We manufacture high-precision components for automotive applications, including engine parts, chassis components, and transmission parts.
                </p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="flex-shrink-0 h-12 w-12 flex items-center justify-center rounded-md bg-primary-100 text-primary-600 mr-4">
                <Activity className="h-6 w-6" />
              </div>
              <div>
                <h4 className="text-lg font-medium text-gray-900">Aerospace Applications</h4>
                <p className="text-gray-700">
                  We provide critical components for the aerospace industry, ensuring they meet the strictest safety and performance standards.
                </p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="flex-shrink-0 h-12 w-12 flex items-center justify-center rounded-md bg-primary-100 text-primary-600 mr-4">
                <Microscope className="h-6 w-6" />
              </div>
              <div>
                <h4 className="text-lg font-medium text-gray-900">Medical Devices</h4>
                <p className="text-gray-700">
                  We produce high-quality components for medical devices, ensuring that they are safe, durable, and precise.
                </p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="flex-shrink-0 h-12 w-12 flex items-center justify-center rounded-md bg-primary-100 text-primary-600 mr-4">
                <Cog className="h-6 w-6" />
              </div>
              <div>
                <h4 className="text-lg font-medium text-gray-900">Industrial Equipment</h4>
                <p className="text-gray-700">
                  From heavy machinery to small industrial tools, we offer precision machining solutions for industrial applications.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;
