import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import jyotiPx20Image from "@/assets/images/jyoti-px-20.jpg";
import jyotiRdx20Image from "@/assets/images/jyoti-rdx-20.jpg";

const Hero = () => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  
  const machineImages = [
    {
      url: jyotiPx20Image,
      alt: "Jyoti PX 20 Machine",
      title: "Jyoti PX 20 Machine"
    },
    {
      url: jyotiRdx20Image,
      alt: "Jyoti RDX 20 Machine",
      title: "Jyoti RDX 20 Machine"
    }
  ];

  useEffect(() => {
    // Auto-rotate images every 5 seconds
    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) => 
        prevIndex === machineImages.length - 1 ? 0 : prevIndex + 1
      );
    }, 5000);
    
    return () => clearInterval(interval);
  }, [machineImages.length]);

  const nextImage = () => {
    setCurrentImageIndex((prevIndex) => 
      prevIndex === machineImages.length - 1 ? 0 : prevIndex + 1
    );
  };

  const prevImage = () => {
    setCurrentImageIndex((prevIndex) => 
      prevIndex === 0 ? machineImages.length - 1 : prevIndex - 1
    );
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      window.scrollTo({
        top: element.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="home" className="relative bg-black h-screen flex flex-col">
      {/* Full screen image slider */}
      <div className="absolute inset-0 z-0">
        {machineImages.map((image, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentImageIndex ? "opacity-100" : "opacity-0"
            }`}
          >
            <img
              src={image.url}
              alt={image.alt}
              className="object-cover w-full h-full"
            />
            <div className="absolute inset-0 bg-black/60 z-10"></div>
          </div>
        ))}
      </div>
      
      {/* Navigation arrows */}
      <div className="absolute top-1/2 left-4 transform -translate-y-1/2 z-30">
        <Button 
          size="icon" 
          variant="ghost" 
          onClick={prevImage} 
          className="text-white bg-black/30 hover:bg-black/50 rounded-full h-12 w-12"
        >
          <ChevronLeft className="h-8 w-8" />
        </Button>
      </div>
      
      <div className="absolute top-1/2 right-4 transform -translate-y-1/2 z-30">
        <Button 
          size="icon" 
          variant="ghost" 
          onClick={nextImage} 
          className="text-white bg-black/30 hover:bg-black/50 rounded-full h-12 w-12"
        >
          <ChevronRight className="h-8 w-8" />
        </Button>
      </div>
      
      {/* Content overlay */}
      <div className="container mx-auto px-4 py-24 md:py-0 flex items-center h-full relative z-20">
        <div className="max-w-3xl">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white font-heading leading-tight">
            Precision Engineering & VMC Machining Excellence
          </h1>
          <h2 className="mt-4 text-2xl md:text-3xl text-primary-400 font-medium">
            {machineImages[currentImageIndex].title}
          </h2>
          <div className="mt-10 flex flex-col sm:flex-row gap-4">
            <Button 
              size="lg" 
              onClick={() => scrollToSection('services')}
              className="bg-primary-600 text-white hover:bg-primary-700"
            >
              Our Services
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              onClick={() => scrollToSection('contact')}
              className="bg-white text-white border border-white hover:bg-white/10"
            >
              Contact Us
            </Button>
          </div>
        </div>
      </div>
      
      {/* Image indicator dots */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-30 flex space-x-3">
        {machineImages.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentImageIndex(index)}
            className={`h-3 w-3 rounded-full transition-all ${
              index === currentImageIndex ? "bg-primary-500 scale-125" : "bg-white/70 hover:bg-white"
            }`}
            aria-label={`Go to image ${index + 1}`}
          />
        ))}
      </div>
    </section>
  );
};

export default Hero;
