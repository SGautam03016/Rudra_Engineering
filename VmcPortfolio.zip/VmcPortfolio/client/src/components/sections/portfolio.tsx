import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PortfolioItem } from "@shared/schema";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";

const Portfolio = () => {
  const [selectedItem, setSelectedItem] = useState<PortfolioItem | null>(null);
  
  const { data: portfolioItems, isLoading, error } = useQuery({
    queryKey: ["/api/portfolio"],
  });

  // Fallback portfolio data if API fails
  const fallbackPortfolio: PortfolioItem[] = [
    {
      id: 1,
      title: "Automotive Components",
      description: "Precision-machined engine parts with tight tolerances",
      imageUrl: "https://images.unsplash.com/photo-1495186578399-253dc42098ef?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
      category: "Automotive"
    },
    {
      id: 2,
      title: "Aerospace Parts",
      description: "Lightweight aluminum components for aircraft systems",
      imageUrl: "https://images.unsplash.com/photo-1583009663341-31412631c9eb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
      category: "Aerospace"
    },
    {
      id: 3,
      title: "Medical Devices",
      description: "High-precision surgical instrument components",
      imageUrl: "https://images.unsplash.com/photo-1581092787765-e31bd53b30c5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
      category: "Medical"
    },
    {
      id: 4,
      title: "Industrial Equipment",
      description: "Heavy-duty components for manufacturing machinery",
      imageUrl: "https://images.unsplash.com/photo-1610262325577-9686ac09d9a1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
      category: "Industrial"
    },
    {
      id: 5,
      title: "Prototype Development",
      description: "Rapid prototype iterations for product development",
      imageUrl: "https://images.unsplash.com/photo-1534313314376-a72289b6181e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
      category: "Prototyping"
    },
    {
      id: 6,
      title: "Electronics Housing",
      description: "Precision-machined enclosures for sensitive electronics",
      imageUrl: "https://images.unsplash.com/photo-1631667960995-9748aca6e9ca?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
      category: "Electronics"
    }
  ];

  const displayItems = portfolioItems || fallbackPortfolio;

  return (
    <section id="portfolio" className="py-16 md:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold font-heading text-gray-900 mb-4">
            Our Portfolio
          </h2>
          <p className="text-xl font-medium font-heading text-gray-700 max-w-3xl mx-auto">
            Showcasing our precision machining capabilities through completed projects
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayItems.map((item) => (
            <Card key={item.id} className="overflow-hidden group">
              <div className="aspect-w-4 aspect-h-3 bg-gray-100 relative overflow-hidden">
                <img 
                  src={item.imageUrl} 
                  alt={item.title} 
                  className="object-cover h-full w-full transform group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                  <Button 
                    className="w-full"
                    onClick={() => setSelectedItem(item)}
                  >
                    View Details
                  </Button>
                </div>
              </div>
              <div className="p-4">
                <h3 className="font-bold text-gray-900 font-heading">{item.title}</h3>
                <p className="text-sm text-gray-600 mt-1">{item.description}</p>
              </div>
            </Card>
          ))}
        </div>
        
        <div className="mt-12 flex justify-center">
          <Button variant="outline" className="flex items-center gap-2">
            View More Projects
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M5 12h14" />
              <path d="m12 5 7 7-7 7" />
            </svg>
          </Button>
        </div>
      </div>

      {/* Item Detail Dialog */}
      <Dialog open={selectedItem !== null} onOpenChange={(open) => !open && setSelectedItem(null)}>
        <DialogContent className="sm:max-w-[500px]">
          {selectedItem && (
            <>
              <DialogHeader>
                <DialogTitle>{selectedItem.title}</DialogTitle>
                <DialogDescription>
                  Category: {selectedItem.category}
                </DialogDescription>
              </DialogHeader>
              <div className="mt-4">
                <img 
                  src={selectedItem.imageUrl} 
                  alt={selectedItem.title} 
                  className="w-full h-auto rounded-md"
                />
                <p className="mt-4 text-gray-700">{selectedItem.description}</p>
              </div>
              <DialogFooter>
                <Button onClick={() => setSelectedItem(null)}>Close</Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
};

export default Portfolio;
