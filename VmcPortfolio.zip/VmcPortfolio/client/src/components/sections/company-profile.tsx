import { FileText, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { COMPANY_NAME, COMPANY_FOUNDED_YEAR } from "@/lib/constants";

const CompanyProfile = () => {
  const profilePdfUrl = "/documents/rudra_engineering_profile.pdf";

  // Use data from the provided PDF
  const companyInfo = [
    { label: "Business Name", value: "Rudra Engineering, Rudra Enterprise" },
    { label: "GST IN", value: "24JHPPS3140J1ZV (Rudra Eng), 24AANPF5555E1ZT (Rudra Ent)" },
    { label: "Mailing Address", value: "10, PDM Estate, Near Shailesh Forging Works, Ravki Main Road, Ravki, Rajkot." },
    { label: "Phone", value: "7777960006" },
    { label: "Email", value: "rudra.engineering@hotmail.com, rudralenterprise@hotmail.com" },
    { label: "Business Type", value: "Precision Machining work" },
    { label: "Total Number of Employees", value: "6" },
    { label: "Working Hours", value: "24 Hours" }
  ];

  const machineDetails = [
    {
      title: "VMC 1",
      specs: [
        { label: "Company Name", value: "Jyoti" },
        { label: "Model Name", value: "RDX 20 (2018)" },
        { label: "RPM", value: "10000" },
        { label: "Machine Type", value: "3 Axis, Through Coolant" },
        { label: "Size", value: "800 X 500 X 500" },
        { label: "Operations", value: "Milling" }
      ]
    },
    {
      title: "VMC 2",
      specs: [
        { label: "Company Name", value: "Jyoti" },
        { label: "Model Name", value: "PX 20 (2022)" },
        { label: "RPM", value: "6000" },
        { label: "Machine Type", value: "3 Axis" },
        { label: "Size", value: "500 X 500 X 500" },
        { label: "Operations", value: "Milling" }
      ]
    }
  ];

  return (
    <section id="company-profile" className="py-16 md:py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold font-heading text-gray-900 mb-4">
            Company Profile
          </h2>
          <p className="text-xl font-medium text-gray-700 max-w-3xl mx-auto">
            {COMPANY_NAME} was established in {COMPANY_FOUNDED_YEAR} for supply of Precision
            Machined Components to leading Automotive, Textile, Hydraulic, Oil & Gas
            Industries.
          </p>
        </div>

        <div className="mb-12">
          <Card className="p-6 mb-8 shadow-md bg-white">
            <div className="mb-6 flex items-center justify-between">
              <h3 className="text-2xl font-bold text-gray-900">Company Information</h3>
              <a 
                href={profilePdfUrl}
                download="Rudra_Engineering_Profile.pdf"
                className="inline-flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors"
              >
                <Download className="h-5 w-5" />
                <span>Download PDF</span>
              </a>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
              {companyInfo.map((item, index) => (
                <div key={index} className="border-b border-gray-200 pb-3">
                  <h4 className="font-medium text-gray-500">{item.label}</h4>
                  <p className="text-gray-900">{item.value}</p>
                </div>
              ))}
            </div>

            <div className="mt-8">
              <h4 className="text-xl font-bold text-gray-900 mb-4">Leadership</h4>
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 bg-primary-100 rounded-full flex items-center justify-center text-primary-600">
                  <span className="font-bold">MS</span>
                </div>
                <div>
                  <p className="font-medium text-gray-900">Mayur Suhagiya</p>
                  <p className="text-gray-500">Managing Director</p>
                </div>
              </div>
            </div>
          </Card>
        </div>

        <div>
          <h3 className="text-2xl font-bold text-gray-900 mb-6">Machine Capacity</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {machineDetails.map((machine, index) => (
              <Card key={index} className="p-6 shadow-md bg-white">
                <h4 className="text-xl font-bold text-primary-600 mb-4">{machine.title}</h4>
                <div className="space-y-3">
                  {machine.specs.map((spec, idx) => (
                    <div key={idx} className="flex justify-between border-b border-gray-100 pb-2">
                      <span className="font-medium text-gray-600">{spec.label}</span>
                      <span className="text-gray-900">{spec.value}</span>
                    </div>
                  ))}
                </div>
              </Card>
            ))}
          </div>
        </div>

        <div className="mt-12 text-center">
          <Button 
            variant="outline" 
            size="lg"
            className="inline-flex items-center gap-2"
            asChild
          >
            <a href={profilePdfUrl} target="_blank" rel="noopener noreferrer">
              <FileText className="h-5 w-5" />
              <span>View Complete Company Profile</span>
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default CompanyProfile;