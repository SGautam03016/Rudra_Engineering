import { Facebook, Twitter, Linkedin, Instagram, MapPin, Phone, Mail } from "lucide-react";
import { COMPANY_SOCIALS, COMPANY_NAME, COMPANY_EMAIL, COMPANY_PHONE, COMPANY_ADDRESS } from "@/lib/constants";

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  const socialLinks = [
    { icon: <Linkedin className="h-4 w-4" />, href: COMPANY_SOCIALS.linkedin, label: "LinkedIn" },
    { icon: <Facebook className="h-4 w-4" />, href: COMPANY_SOCIALS.facebook, label: "Facebook" },
    { icon: <Twitter className="h-4 w-4" />, href: COMPANY_SOCIALS.twitter, label: "Twitter" },
    { icon: <Instagram className="h-4 w-4" />, href: COMPANY_SOCIALS.instagram, label: "Instagram" }
  ];

  const quickLinks = [
    { href: "#home", label: "Home" },
    { href: "#about", label: "About Us" },
    { href: "#services", label: "Services" },
    { href: "#portfolio", label: "Portfolio" },
    { href: "#company-profile", label: "Company Profile" },
    { href: "#contact", label: "Contact" }
  ];
  
  const serviceLinks = [
    { href: "#services", label: "CNC Milling on Jyoti RDX 20" },
    { href: "#services", label: "Prototyping" },
    { href: "#services", label: "Production Machining" },
    { href: "#services", label: "Design & Engineering" },
    { href: "#services", label: "Material Finishing" }
  ];

  return (
    <footer className="bg-gray-900 text-gray-300 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          <div>
            <div className="flex items-center mb-6">
              <div className="h-10 w-10 bg-primary-600 rounded-md flex items-center justify-center text-white font-bold text-xl">
                RE
              </div>
              <span className="ml-3 text-xl font-bold text-white font-heading">{COMPANY_NAME}</span>
            </div>
            <p className="mb-6">
              Delivering exceptional precision machining services with our Jyoti RDX 20 VMC machine. Quality, reliability, and craftsmanship in every part we produce.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((link, index) => (
                <a 
                  key={index}
                  href={link.href} 
                  className="h-8 w-8 rounded-full bg-gray-800 text-gray-300 flex items-center justify-center hover:bg-primary-600 hover:text-white transition-colors"
                  aria-label={link.label}
                >
                  {link.icon}
                </a>
              ))}
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-bold text-white font-heading mb-6">Quick Links</h3>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <a 
                    href={link.href} 
                    className="hover:text-primary-400 transition-colors"
                    onClick={(e) => {
                      if (link.href.startsWith("#")) {
                        e.preventDefault();
                        const targetElement = document.getElementById(link.href.substring(1));
                        if (targetElement) {
                          window.scrollTo({
                            top: targetElement.offsetTop - 80,
                            behavior: 'smooth'
                          });
                        }
                      }
                    }}
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold text-white font-heading mb-6">Services</h3>
            <ul className="space-y-3">
              {serviceLinks.map((link, index) => (
                <li key={index}>
                  <a href={link.href} className="hover:text-primary-400 transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold text-white font-heading mb-6">Contact Info</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <MapPin className="h-5 w-5 text-primary-500 mt-1 mr-3" />
                <span>{COMPANY_ADDRESS.street}<br/>{COMPANY_ADDRESS.city}<br/>{COMPANY_ADDRESS.state}, {COMPANY_ADDRESS.zip}</span>
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 text-primary-500 mr-3" />
                <a href={`tel:${COMPANY_PHONE}`} className="hover:text-primary-400">{COMPANY_PHONE}</a>
              </li>
              <li className="flex items-center">
                <Mail className="h-5 w-5 text-primary-500 mr-3" />
                <a href={`mailto:${COMPANY_EMAIL}`} className="hover:text-primary-400">{COMPANY_EMAIL}</a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p>© {currentYear} {COMPANY_NAME}. All rights reserved.</p>
          <div className="mt-4 md:mt-0 flex space-x-6">
            <a href="#" className="text-sm hover:text-primary-400 transition-colors">Privacy Policy</a>
            <a href="#" className="text-sm hover:text-primary-400 transition-colors">Terms of Service</a>
            <a href="#" className="text-sm hover:text-primary-400 transition-colors">Sitemap</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
