export const COMPANY_NAME = "Rudra Engineering";
export const COMPANY_TAGLINE = "VMC Machining Specialists";
export const COMPANY_DESCRIPTION = "We are providing CNC VMC Job Work (CNC Vertical Machine Center Job Work). We use quality grades of various metals as per customers requirements in the manufacturing of our range that comprise of precision components, CNC machined components, engineering components.";
export const COMPANY_PHONE = "7777960006";
export const COMPANY_EMAIL = "rudra.engineering@hotmail.com";
export const COMPANY_ADDRESS = {
  street: "Rauki",
  city: "Rajkot",
  state: "Gujarat",
  zip: "India"
};

export const COMPANY_FOUNDED_YEAR = 2018;
export const COMPANY_SOCIALS = {
  linkedin: "#",
  facebook: "https://www.facebook.com/share/19qABZNchm/",
  twitter: "#",
  instagram: "https://www.instagram.com/rudra.eng?igsh=MTRmOWtkOHNhaTVsdg=="
};

export const BUSINESS_HOURS = {
  weekdays: "Monday - Friday: 8am - 5pm",
  weekend: "Saturday - Sunday: Closed"
};

export const META_TAGS = {
  title: `${COMPANY_NAME} - ${COMPANY_TAGLINE}`,
  description: COMPANY_DESCRIPTION,
  keywords: "VMC machining, precision engineering, CNC milling, manufacturing, prototyping"
};
